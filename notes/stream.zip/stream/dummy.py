import random, time

while random.random() <= 0.90:
    time.sleep(1)